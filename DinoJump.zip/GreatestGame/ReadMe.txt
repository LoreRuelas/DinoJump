DINO JUMP

Para crear este programa...

1) Descomprimir el Zip
2) Abrir la carpeta desxcomprimida en CLion
3) Abrir main.c
    ** Las librerías ya estan incluidas en el CMake, por lo que no se espera problemas de compilación
4) Compilar el programa
5) Ejecutar el programa