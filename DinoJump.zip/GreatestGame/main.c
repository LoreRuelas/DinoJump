
/*
 * DINO JUMP
 *      -    Es un dinosaurio que brinca pisos
 * Por:
 *      -   Renata y Lore
 * Objetivo:
 *      -   Pasar los niveles (Este caso 2)
 * Obstáculos:
 *      -   En un punto los pisos cambian de lugar
 *      -   No debes tocar al dino enemigo o mueres
 *      -   No debes caer al vacío (área gris) porque a cierta profundidad muere el Dino
 *
 */
#include "raylib.h"
#include "raymath.h"
// gruelas #include "stdio.h"
#include "stdlib.h"


// Definimos variables globales
#define G 400
#define PLAYER_JUMP_SPD 350.0f
#define PLAYER_HOR_SPD 200.0f

// Struct que guarda info de sprites
typedef struct png_details
{
    char * name;
    int numFrames;
    bool atack;
} PngDetails;

typedef struct sprite_struct
{
    Texture2D texture;
    Rectangle mask;
    int frameCount;
}Sprite;


typedef struct Player {
    Vector2 position;
    float speed;
    bool canJump;
} Player;

typedef struct EnvItem {
    Rectangle rect;
    int blocking;
    Color color;
} EnvItem;


void UpdatePlayer(Player *player, EnvItem *envItems, int envItemsLength, float delta);
void UpdateCameraCenter(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height);
void UpdateCameraCenterInsideMap(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height);
void UpdateCameraCenterSmoothFollow(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height);
void UpdateCameraEvenOutOnLanding(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height);
void UpdateCameraPlayerBoundsPush(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height);
PngDetails SelectTexture(Player player, PngDetails details);
void CreateBlocks(EnvItem envItems[]);
Player PaintEnemy (Rectangle playerRect, int contador, Player enemy);
bool DetectEnemy(Player enemyChar, Player player, PngDetails details);
void DrawMessages(Player player);
void DrawEndMsg(bool win);
bool MoveBars(Player player, bool modificaPisos, PngDetails textureDetails, EnvItem envItems[]);
Player InitPlayer(Player player);
Camera2D InitCamera(Camera2D camera, Player player, int screenWidth, int screenHeight);
int EnemyPosition(int contador);
void PrintWelcome(int screenWidth, int screenHeight);


int main(void)
{
    // Initialization

    const int screenWidth = 800;
    const int screenHeight = 450;

    InitWindow(screenWidth, screenHeight, "DinoJump");

    // Inicia la posición del Dino
    Player player = { 0 };
    player = InitPlayer(player);

    // Inicia al dino enemigo
    Player enemy = { 0 };
    enemy.position.y = -2600;

    // Inicia los detalles(info) de los sprites
    PngDetails details;
    int width = 140;

    // Inicia y crea bloques
    EnvItem envItems[39];
    CreateBlocks(envItems);
    int envItemsLength = sizeof(envItems)/sizeof(envItems[0]);

    // Inicia info cámara
    Camera2D camera = { 0 };
    camera = InitCamera(camera, player, screenWidth, screenHeight);

    // Store pointers to the multiple update camera functions
    void (*cameraUpdaters[])(Camera2D*, Player*, EnvItem*, int, float, int, int) = {
            UpdateCameraCenter,
            UpdateCameraCenterInsideMap,
            UpdateCameraCenterSmoothFollow,
            UpdateCameraEvenOutOnLanding,
            UpdateCameraPlayerBoundsPush
    };

    int cameraOption = 0;
    int cameraUpdatersLength = sizeof(cameraUpdaters)/sizeof(cameraUpdaters[0]);

    SetTargetFPS(25);

    // Initialization of variables

    bool win = false;
    int vecesDeEjecutar = 1;
    int muertoDinoFrames = 0;
    int imageSelect = 0;
    bool condition = true;
    bool modificaPisos = true;
    int contador = 0;
    int playerPosicionX = 355;
    bool FirstPlay = true;

    // Se mantiene ventana abierta mientras no ESC o "X"
    while (!WindowShouldClose())
    {
        // Da msg de bienvenida hasta que se presione ENTER
        while (IsKeyUp(KEY_ENTER) && (FirstPlay == true)) {
            PrintWelcome(screenWidth, screenHeight);
            // Se inicializa variable que se al jugar
            // gruelas vecesDeEjecutar = 1;
            if (WindowShouldClose()){
                CloseWindow();
            }
        }
        // Entra al juego
        while (condition) {

            FirstPlay = false;

            // Update Cámara
            float deltaTime = GetFrameTime();

            UpdatePlayer(&player, envItems, envItemsLength, deltaTime);

            // Para hacer Zoom
            camera.zoom += ((float)GetMouseWheelMove()*0.05f);

            if (camera.zoom > 3.0f) camera.zoom = 3.0f;
            else if (camera.zoom < 0.25f) camera.zoom = 0.25f;

            if (IsKeyPressed(KEY_R))
            {
                camera.zoom = 1.0f;
                player.position = (Vector2){ 400, 280 };
            }

            if (IsKeyPressed(KEY_C)) cameraOption = (cameraOption + 1)%cameraUpdatersLength;

            // Call update camera function by its pointer
            cameraUpdaters[cameraOption](&camera, &player, envItems, envItemsLength, deltaTime, screenWidth, screenHeight);


            // Draw
            BeginDrawing();
            ClearBackground(LIGHTGRAY);
            BeginMode2D(camera);

            for (int i = 0; i < envItemsLength; i++){
                DrawRectangleRec(envItems[i].rect, envItems[i].color);
            }

            // Selecciona texture (sprites)
            PngDetails textureDetails = SelectTexture(player, details);
            Texture2D t = LoadTexture(textureDetails.name);


            // Altera dirección correspondientemente
            if (IsKeyDown(KEY_RIGHT)){
                playerPosicionX = player.position.x - 45;
                width = 140;
            } else if (IsKeyDown(KEY_LEFT)) {
                width = -140;
                playerPosicionX = player.position.x -90;
            }

            Rectangle playerRect = { imageSelect, 0, width, 97};
            imageSelect = imageSelect + 140;

            // Que inicie de 0 la iteración de los sprites
            if ( imageSelect >= textureDetails.numFrames * 140 ) {
                imageSelect = 0;
            }
            // playerPositionX se debe alterar para que el Dino no se caiga en ningun punto de la barra / creemos es por una "falla" en la función
            DrawTextureRec(t, playerRect, (Vector2){ playerPosicionX, player.position.y - 95 }, RAYWHITE);

            // Enemigo
            Player enemyChar = PaintEnemy (playerRect, contador, enemy);

            // Checa si el enemigo mató a Dino
            bool DeadOrNot = DetectEnemy(enemyChar, player, details);
            if ( DeadOrNot ) {
                details.atack = DeadOrNot;
            }

            // Posición de enemigo
            contador = EnemyPosition(contador);

            EndMode2D();
            DrawMessages(player);

            // Checa si ganó
            if (player.position.y - 95 < -3150) {
                win = true;
                WaitTime(1500);
                vecesDeEjecutar = 0;
                condition = false;
            }

            EndDrawing();

            // 2ndo nivel - superpoder activado - vida extra
            if (player.position.y <= -1000 && vecesDeEjecutar == 1){
                vecesDeEjecutar++;
            }

            // Detecta cuando se muere para que se acabe el juego - Que se itere 1 vez el death
            // Validamos con el debugger que la condición sí funciona
            if ( textureDetails.name == "Assets/dino_death_8.png"  && muertoDinoFrames == 0 ) {
                muertoDinoFrames = 9; // Permite mostrar completa la muerte del Dino
            }
            if ( muertoDinoFrames > 1 ) {
                muertoDinoFrames--;
            } else if ( muertoDinoFrames == 1 ) {
                vecesDeEjecutar--;
                muertoDinoFrames = 0;
                condition = false;
                WaitTime(1000);
            }

            // 2ndo nivel se mueven los pisos de manera aleatoria cuando alcanza cierta altura
            modificaPisos = MoveBars(player, modificaPisos, textureDetails, envItems);

            // Cierra la ventana si el ususario cerró el juego
            if ( WindowShouldClose() ) {
                CloseWindow();
            }
        }

        // Si tiene 0 vidas - ImprimeMsg Salida - Regresa pag bienvenida
        if ( vecesDeEjecutar == 0) {
            BeginDrawing();
            DrawEndMsg(win);
            EndDrawing();
            WaitTime(2000);
            FirstPlay = true;
            condition = true;
        } else { // Vuelve a iniciar el juego - Entra al while interno
            FirstPlay = false;
            condition = true;
        }

        // Juego nuevo - Se inicializan variables que se modificaron
        player.position = (Vector2){ 400, 280 };
        width = 140;
        details.atack = false;
        win = false;
        vecesDeEjecutar = 1;
        muertoDinoFrames = 0;
        imageSelect = 0;
        modificaPisos = true;
        contador = 0;
        playerPosicionX = 355;
    }
    return 0;
}

void PrintWelcome(int screenWidth, int screenHeight) {
    BeginDrawing();
    ClearBackground(RAYWHITE);
    DrawRectangle(0, 0, screenWidth, screenHeight, RAYWHITE);
    DrawText("<< DINO JUMP >>", 250, 150, 40, DARKGREEN);
    DrawText("Presiona ENTER para JUGAR", 260, 220, 20, DARKGREEN);
    EndDrawing();
}
int EnemyPosition(int contador){
    if (contador == 500){
        contador = 0;
    }else{
        contador = contador + 5;
    }
    return contador;
}

Camera2D InitCamera(Camera2D camera, Player player, int screenWidth, int screenHeight) {
    camera.target = player.position;
    camera.offset = (Vector2) {screenWidth / 2.0f, screenHeight / 2.0f};
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;
    return camera;
}

Player InitPlayer(Player player){
    player.position = (Vector2){ 400, 280 };
    player.speed = 0;
    player.canJump = false;
    return player;
}

// 2ndo nivel en cierto punto los pisos cambian de posición de manera random
bool MoveBars(Player player, bool modificaPisos, PngDetails textureDetails, EnvItem envItems[]){
    if (player.position.y <= -1600 && modificaPisos == true) {
        if ( textureDetails.name == "Assets/dino_jump_12.png" ) {
            CreateBlocks(envItems);
            modificaPisos = false;
        }
    }
    return modificaPisos;
}

void DrawEndMsg(bool win){
    if (win == true) {
        DrawText("OBJETIVO", 400, 200, 50, DARKGREEN);
        DrawText("LOGRADO", 400, 280, 50, DARKGREEN);
    }else {
        DrawText("GAME OVER", 100, 280, 100, BLACK);
    }
}

void DrawMessages(Player player) {
    DrawText("OBJETIVO:", 40, 20, 20, BLACK);
    DrawText("Llegar a la cima sin caer en el vacío", 40, 40, 15, BLACK);
    if (player.position.y - 95 > -200) {
        DrawText("Controles:", 20, 70, 10, BLACK);
        DrawText("- Flecha derecha/izquierda para moverse", 40, 90, 10, DARKGRAY);
        DrawText("- Espacio para brincar", 40, 110, 10, DARKGRAY);
        DrawText("- Rueda del Mouse para el Zoom, R to resetear el zoom", 40, 130, 10, DARKGRAY);
        DrawText("- C para cambiar el modo de cámara", 40, 150, 10, DARKGRAY);
    }
    if (player.position.y - 95 < -1050) {
        DrawText("SEGUNDO NIVEL", 40, 70, 20, PURPLE);
        DrawText("Superpoder Activado: Vida extra", 40, 90, 15, PURPLE);
        DrawText("¡ CUIDADO ! LOS PISOS DE MUEVEN", 40, 120, 15, PURPLE);
    }
    if (player.position.y - 95 < -2400 && player.position.y - 95 > -2600) {
        DrawText("¡ CUIDADO !", 525, 20, 25, RED);
        DrawText("No toques al enemigo o te matará", 450, 40, 20, RED);
    }
    if (player.position.y - 95 < -2700) {
        DrawText("META", 400, -3100, 100, GREEN);
    }
}

// Detecta si hay colisión entre Dino y Enemigo
bool DetectEnemy(Player enemyChar, Player player, PngDetails details){
    int desplazamientoX = 60;
    int desplazamientoY = 40;
    int EnemX = enemyChar.position.x;
    int EnemXw = EnemX + desplazamientoX;
    int dinoX = player.position.x - 20;
    int dinoXw = dinoX + desplazamientoX;

    int EnemY = enemyChar.position.y;
    int dinoY = player.position.y - 95;
    int EnemYw = EnemY + desplazamientoY;
    int dinoYw = dinoY + desplazamientoY;

    if (  (EnemX >= dinoX ) && (EnemX <= dinoXw )) {
        if ( (EnemY >= dinoY ) && (EnemY <= dinoYw) ) {
            return true;
        } else if ( (EnemYw >= dinoY ) && (EnemYw <= dinoYw) ) {
            return true;
        } else {
            return false;
        }
    } else  if ( (EnemXw >= dinoX) && (EnemXw <= dinoXw) ) {
        if ( ( EnemY >= dinoY ) && (EnemY <= dinoYw ) )  {
            return true;
        } else if ( ( EnemYw >= dinoY ) && (EnemYw <= dinoYw ) )  {
            return true;
        } else {
            return false;
        }
    }else {
        return false;
    }
}

// Muestra y mueve al enemigo
Player PaintEnemy (Rectangle playerRect, int contador, Player enemy){
    Texture2D tM = LoadTexture("Assets/DinoMalo_Corriendo_8.png");
    int limiteBajo = 300;
    int limiteAlto = 550;
    if ( contador < 250 ) {
        int posicion = limiteBajo + contador;
        playerRect.width = 140;
        enemy.position.x = posicion;
        DrawTextureRec(tM, playerRect, (Vector2) {posicion, enemy.position.y}, RAYWHITE);
    }else {
        int posicion = limiteAlto - ( contador -250 );
        enemy.position.x = posicion;
        playerRect.width = -140;
        DrawTextureRec(tM, playerRect, (Vector2){ posicion, enemy.position.y}, RAYWHITE);
    }

    return enemy;
}

// Crea los bloques de manera random
void CreateBlocks(EnvItem envItems[]){
    // Bloques principales fijos
    // "Cast" Casting para permitir creación del objeto - Para que se identifique lo de "{}" como un EnvItem
    envItems[0] = (EnvItem) {{ 300, -9500, 400, 10000 }, 0, RAYWHITE };
    envItems[1] = (EnvItem) {{ 300, 400, 400, 200 }, 1, GRAY };
    envItems[2] = (EnvItem) {{ 550, 300, 110, 10 }, 1, BLUE };
    envItems[3] = (EnvItem) {{ 330, -1000, 360, 10 }, 1, PURPLE };
    envItems[4] = (EnvItem) {{ 330, -2500, 360, 10 }, 1, BLUE };
    envItems[5] = (EnvItem) {{ 330, -3100, 360, 10 }, 1, GREEN };


    // Bloques secundarios aleatorios
    int valorY = 200;
    for ( int counter= 6; counter < 39 ; counter++ ) {
        EnvItem envItem6 =  {{ (300 + rand() % (601 - 300)), valorY, 110, 10 }, 1, BLUE };
        envItems[counter] = envItem6;
        valorY = valorY - 100;
    }
}

// Define el movimiento (sprite) dependiendo de la tecla presionada
PngDetails SelectTexture(Player player, PngDetails details) {

    if ((player.position.y - 95) > 400 || details.atack == true) {
        details.name = "Assets/dino_death_8.png";
        details.numFrames = 8;
    } else if (IsKeyDown(KEY_SPACE)) {
        details.name = "Assets/dino_jump_12.png";
        details.numFrames = 12;
    } else if (IsKeyDown(KEY_RIGHT)){
        details.name = "Assets/dino_walk_10.png";
        details.numFrames = 10;
    } else if (IsKeyDown(KEY_LEFT)) {
        details.name = "Assets/dino_walk_10.png";
        details.numFrames = 10;
    } else {
        details.name = "Assets/dino_idle_10.png";
        details.numFrames = 10;
    }
    return details;
}



// Mueve al jugador con respecto de la cámara (fondo) & dependiendo si choca con un piso lo detiene o no al Dino (hitObstacle)
void UpdatePlayer(Player *player, EnvItem *envItems, int envItemsLength, float delta)
{
    if (IsKeyDown(KEY_LEFT)) player->position.x -= PLAYER_HOR_SPD*delta;
    if (IsKeyDown(KEY_RIGHT)) player->position.x += PLAYER_HOR_SPD*delta;
    if (IsKeyDown(KEY_SPACE) && player->canJump)
    {
        player->speed = -PLAYER_JUMP_SPD;
        player->canJump = false;
    }

    int hitObstacle = 0;
    for (int i = 0; i < envItemsLength; i++)
    {
        EnvItem *ei = envItems + i;
        Vector2 *p = &(player->position);
        if (ei->blocking &&
            ei->rect.x <= p->x &&
            ei->rect.x + ei->rect.width >= p->x &&
            ei->rect.y >= p->y &&
            ei->rect.y < p->y + player->speed*delta)
        {
            hitObstacle = 1;
            player->speed = 0.0f;
            p->y = ei->rect.y;
        }
    }

    if (!hitObstacle)
    {
        player->position.y += player->speed*delta;
        player->speed += G*delta;
        player->canJump = false;
    }
    else player->canJump = true;
}

// TODAS A CONTINUACIÓN - Actualizan la cámara(fondo) -> el dino queda siempre en el centro
void UpdateCameraCenter(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height)
{
    camera->offset = (Vector2){ width/2.0f, height/2.0f };
    camera->target = player->position;
}


void UpdateCameraCenterInsideMap(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height)
{
    camera->target = player->position;
    camera->offset = (Vector2){ width/2.0f, height/2.0f };
    float minX = 1000, minY = 1000, maxX = -1000, maxY = -1000;

    for (int i = 0; i < envItemsLength; i++)
    {
        EnvItem *ei = envItems + i;
        minX = fminf(ei->rect.x, minX);
        maxX = fmaxf(ei->rect.x + ei->rect.width, maxX);
        minY = fminf(ei->rect.y, minY);
        maxY = fmaxf(ei->rect.y + ei->rect.height, maxY);
    }

    Vector2 max = GetWorldToScreen2D((Vector2){ maxX, maxY }, *camera);
    Vector2 min = GetWorldToScreen2D((Vector2){ minX, minY }, *camera);

    if (max.x < width) camera->offset.x = width - (max.x - width/2);
    if (max.y < height) camera->offset.y = height - (max.y - height/2);
    if (min.x > 0) camera->offset.x = width/2 - min.x;
    if (min.y > 0) camera->offset.y = height/2 - min.y;
}

void UpdateCameraCenterSmoothFollow(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height)
{
    static float minSpeed = 30;
    static float minEffectLength = 10;
    static float fractionSpeed = 0.8f;

    camera->offset = (Vector2){ width/2.0f, height/2.0f };
    Vector2 diff = Vector2Subtract(player->position, camera->target);
    float length = Vector2Length(diff);

    if (length > minEffectLength)
    {
        float speed = fmaxf(fractionSpeed*length, minSpeed);
        camera->target = Vector2Add(camera->target, Vector2Scale(diff, speed*delta/length));
    }
}

void UpdateCameraEvenOutOnLanding(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height)
{
    static float evenOutSpeed = 700;
    static int eveningOut = false;
    static float evenOutTarget;

    camera->offset = (Vector2){ width/2.0f, height/2.0f };
    camera->target.x = player->position.x;

    if (eveningOut)
    {
        if (evenOutTarget > camera->target.y)
        {
            camera->target.y += evenOutSpeed*delta;

            if (camera->target.y > evenOutTarget)
            {
                camera->target.y = evenOutTarget;
                eveningOut = 0;
            }
        }
        else
        {
            camera->target.y -= evenOutSpeed*delta;

            if (camera->target.y < evenOutTarget)
            {
                camera->target.y = evenOutTarget;
                eveningOut = 0;
            }
        }
    }
    else
    {
        if (player->canJump && (player->speed == 0) && (player->position.y != camera->target.y))
        {
            eveningOut = 1;
            evenOutTarget = player->position.y;
        }
    }
}

void UpdateCameraPlayerBoundsPush(Camera2D *camera, Player *player, EnvItem *envItems, int envItemsLength, float delta, int width, int height)
{
    static Vector2 bbox = { 0.2f, 0.2f };

    Vector2 bboxWorldMin = GetScreenToWorld2D((Vector2){ (1 - bbox.x)*0.5f*width, (1 - bbox.y)*0.5f*height }, *camera);
    Vector2 bboxWorldMax = GetScreenToWorld2D((Vector2){ (1 + bbox.x)*0.5f*width, (1 + bbox.y)*0.5f*height }, *camera);
    camera->offset = (Vector2){ (1 - bbox.x)*0.5f * width, (1 - bbox.y)*0.5f*height };

    if (player->position.x < bboxWorldMin.x) camera->target.x = player->position.x;
    if (player->position.y < bboxWorldMin.y) camera->target.y = player->position.y;
    if (player->position.x > bboxWorldMax.x) camera->target.x = bboxWorldMin.x + (player->position.x - bboxWorldMax.x);
    if (player->position.y > bboxWorldMax.y) camera->target.y = bboxWorldMin.y + (player->position.y - bboxWorldMax.y);
}
